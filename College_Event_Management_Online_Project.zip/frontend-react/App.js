import React, { useEffect, useState } from 'react';

function App() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetch('https://your-render-backend-url/admin/events')
      .then(res => res.json())
      .then(data => setEvents(data));
  }, []);

  return (
    <div>
      <h1>College Event List</h1>
      <ul>
        {events.map((event, index) => (
          <li key={index}>{event.name} - {event.date}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;