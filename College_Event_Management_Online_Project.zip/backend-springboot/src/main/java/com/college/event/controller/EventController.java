package com.college.event.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/admin")
public class EventController {
    @GetMapping("/events")
    public List<Map<String, String>> getEvents() {
        Map<String, String> event = new HashMap<>();
        event.put("name", "Tech Fest");
        event.put("date", "2025-08-10");
        return Collections.singletonList(event);
    }
}